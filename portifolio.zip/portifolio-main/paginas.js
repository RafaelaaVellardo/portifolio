function linguagens(){
    window.location.href="paginaLing.html"
}
function humanas(){
    window.location.href="paginaHum.html"
}
function natureza(){
    window.location.href="paginaNat.html"
}
function matematica(){
    window.location.href="paginaMat.html"
}
function tecnico(){
    window.location.href="paginaTec.html"
}
function outros(){
    window.location.href="paginaOutr.html"
}
function inicio(){
    window.location.href="inicio.html"
}